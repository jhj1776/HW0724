package com.kh.hw0724;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw0724Application {

	public static void main(String[] args) {
		SpringApplication.run(Hw0724Application.class, args);
	}

}
