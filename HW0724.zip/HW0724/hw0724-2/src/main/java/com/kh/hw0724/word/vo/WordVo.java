package com.kh.hw0724.word.vo;

import lombok.Data;

@Data
public class WordVo {
    private String no;
    private String length;
    private String word;
    private String categoryId;
    private String activeWord;
    private String categoryName;
}
