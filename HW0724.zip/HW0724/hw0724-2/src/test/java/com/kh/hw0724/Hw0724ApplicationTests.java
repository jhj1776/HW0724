package com.kh.hw0724;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw0724ApplicationTests {

	@Test
	void contextLoads() {
	}

}
